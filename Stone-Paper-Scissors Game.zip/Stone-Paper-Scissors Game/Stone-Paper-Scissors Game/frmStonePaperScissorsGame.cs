﻿using Stone_Paper_Scissors_Game.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stone_Paper_Scissors_Game
{
    public partial class frmStonePaperScissorsGame : Form
    {

        stGameIssue GameIssue;
        enChoises PlayerChoise;

        public frmStonePaperScissorsGame()
        {
            InitializeComponent();
        }

        enum enWinner
        {
            Computer,
            Player,
            Drow,
            InProgress

        }
        enum enChoises
        {
            Stone = 1,
            Paper = 2,
            Scissors = 3
        }
       struct stGameIssue
        {
            public enWinner winner;
            public enChoises CopmuterChoise;
            public int ComputerWonsTime;
            public int PlayerWonsTime;
        }

        enChoises ComputerChoise()
        {
            Random ComputerChoise = new Random();
            return (enChoises)ComputerChoise.Next(1, 4);
        }

        void UpdateComputerImage()
        {

            GameIssue.CopmuterChoise = ComputerChoise();

            switch (GameIssue.CopmuterChoise)
            {
                case enChoises.Stone:
                    pbComputer.Image = Resources.Stone1;
                    break;

                case enChoises.Paper:
                    pbComputer.Image = Resources.Paper1;
                    break;

                case enChoises.Scissors:
                    pbComputer.Image = Resources.Scissors__1_;
                    break;
            }
        }

        void UpdatePlayerImage()
        {

            switch (PlayerChoise)
            {
                case enChoises.Stone:
                    pbPlayer.Image = Resources.Stone1;
                    break;

                case enChoises.Paper:
                    pbPlayer.Image = Resources.Paper1;
                    break;

                case enChoises.Scissors:
                    pbPlayer.Image = Resources.Scissors__1_;
                    break;
            }
        }

        void CheckWinner()
        {

            if (GameIssue.CopmuterChoise == PlayerChoise)
            {
                GameIssue.winner = enWinner.Drow;
                lblWinner.Text = "Drow";
                lblWinner.ForeColor = Color.Yellow;
                return;
            }
                

                switch (GameIssue.CopmuterChoise)
            {
                
                case enChoises.Stone :
                    if (PlayerChoise == enChoises.Scissors)
                    {
                        GameIssue.winner = enWinner.Computer;
                        lblWinner.Text = "Computer Won";
                        lblWinner.ForeColor = Color.Red;
                        GameIssue.ComputerWonsTime++;
                        return;
                    }
                    break;

                case enChoises.Paper:
                    if (PlayerChoise == enChoises.Stone)
                    {
                        GameIssue.winner = enWinner.Computer;
                        lblWinner.Text = "Computer Won";
                        lblWinner.ForeColor = Color.Red;
                        GameIssue.ComputerWonsTime++;
                        return;
                    }
                    break;

                case enChoises.Scissors:
                    if (PlayerChoise == enChoises.Paper)
                    {
                        GameIssue.winner = enWinner.Computer;
                        lblWinner.Text = "Computer Won";
                        lblWinner.ForeColor = Color.Red;
                        GameIssue.ComputerWonsTime++;
                        return;
                    }
                    break;
            }

            GameIssue.winner = enWinner.Player;
            lblWinner.Text = "Player Won";
            lblWinner.ForeColor = Color.Green;
            GameIssue.PlayerWonsTime++;
        }

        void UpdateScore()
        {
            lblPlayerScore.Text = GameIssue.PlayerWonsTime.ToString();
            lblComputerScore.Text = GameIssue.ComputerWonsTime.ToString();
        }

        void ResetGameInfo()
        {
            GameIssue.PlayerWonsTime = 0;
            GameIssue.ComputerWonsTime = 0;
            GameIssue.winner = enWinner.InProgress;
        }
        void ResetImages()
        {
            pbComputer.Image = Resources.question_mark_96;
            pbPlayer.Image = Resources.question_mark_96;
        }
        void ResetLables()
        {
            lblWinner.Text = "";
            lblPlayerScore.Text = "0";
            lblComputerScore.Text = "0";
        }
        void ResetGame()
        {
            ResetGameInfo();
            ResetImages();
            ResetLables();
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetGame();
        }

        void StrartGame()
        {
            UpdatePlayerImage();
            UpdateComputerImage();
            CheckWinner();
            UpdateScore();
        }

        private void pbStone_Click(object sender, EventArgs e)
        {
            PlayerChoise = enChoises.Stone;
            StrartGame();
        }

        private void pbPaper_Click(object sender, EventArgs e)
        {
            PlayerChoise = enChoises.Paper;
            StrartGame();
        }

        private void pbSessier_Click(object sender, EventArgs e)
        {
            PlayerChoise = enChoises.Scissors;
            StrartGame();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmStartGame.instance.Close();
        }


    }
}
